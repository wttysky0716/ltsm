.. _kernel_approximation_examples:

Kernel Approximation
--------------------

Examples concerning the :mod:`sklearn.kernel_approximation` module.
